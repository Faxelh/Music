import Foundation
import SwiftUI

let audioExtensions: Set<String> = ["m4a", "mp3", "aac", "wav", "flac", "aif", "aiff", "caf", "m4b", "alac"]

/// Un morceau du dossier de Music (copié avec 3uTools, l'app Fichiers…).
struct Song: Identifiable, Hashable, Codable {
    /// Chemin relatif au dossier Documents : identifiant stable.
    var id: String
    var title: String
    var artist: String?
    var album: String?
    var genre: String?
    var year: Int?
    var trackNumber: Int?
    var duration: Double = 0
    var hasArtwork = false
    var size: Double = 0
    var modified: Double = 0
    var added: Double = 0

    var url: URL { LibraryStore.documents.appendingPathComponent(id) }

    var displayArtist: String { artist ?? L("Artiste inconnu") }

    var folder: String {
        let parent = (id as NSString).deletingLastPathComponent
        return parent.isEmpty ? L("Music") : parent
    }

    /// Clé courte pour les fichiers liés (pochette, paroles).
    var key: String { LibraryStore.hash(id) }
}

/// Une playlist (avec sa photo de couverture facultative).
struct Playlist: Identifiable, Hashable, Codable {
    var id: String
    var name: String
    var songIDs: [String]
    var hasCover = false
    var created: Double = Date().timeIntervalSince1970
}

/// Artiste ou album.
struct MusicGroup: Identifiable, Hashable {
    let id: String
    let name: String
    let subtitle: String
    let songs: [Song]
    let artwork: Song?
}

/// Données personnelles de la bibliothèque (enregistrées sur l'iPhone).
struct UserData: Codable {
    var favorites: [String] = []
    var playlists: [Playlist] = []
    var playCounts: [String: Int] = [:]
    var lastPlayed: [String: Double] = [:]
    var customArtwork: [String] = []
}

enum LibraryRoute: Hashable {
    case songs
    case artists
    case albums
    case playlists
    case favorites
    case mostPlayed
    case folders
    case artist(String)
    case album(String)
    case playlist(String)
    case folder(String)
}

enum AppTab: Hashable {
    case home, library, search, settings
}

struct Toast: Identifiable, Equatable {
    enum Kind {
        case info, ok, warn, error
    }

    let id = UUID()
    let text: String
    let kind: Kind
}
