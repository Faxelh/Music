import SwiftUI

/// Temps de lecture « en direct » (entre deux relevés du moteur) pour des animations fluides.
func liveTime(_ player: AudioEngine, at date: Date) -> Double {
    guard player.isPlaying else { return player.currentTime }
    let elapsed = date.timeIntervalSince(player.timeStamp) * Double(player.rate)
    return min(player.duration, player.currentTime + max(0, min(elapsed, 1)))
}

// MARK: - Fonds animés

struct PlayerBackground: View {
    @EnvironmentObject var player: AudioEngine
    @ObservedObject private var appearance = Appearance.shared
    @ObservedObject private var library = LibraryStore.shared

    var body: some View {
        let song = player.current
        let colors = library.colors(for: song)
        ZStack {
            Color.black
            switch appearance.background {
            case .aurora:
                AuroraView(colors: colors, animated: appearance.animations)
            case .artwork:
                ArtworkBackdrop(url: song.flatMap { library.artworkURL($0) }, colors: colors, animated: appearance.animations)
            case .photo:
                PhotoBackdrop(image: appearance.playerImage, colors: colors, animated: appearance.animations)
            case .gradient:
                RainbowBackdrop(colors: colors, animated: appearance.animations)
            case .black:
                LinearGradient(colors: [Color(white: 0.08), .black], startPoint: .top, endPoint: .bottom)
            }
            Color.black.opacity(appearance.background == .black ? 0 : appearance.backgroundDim)
        }
        .ignoresSafeArea()
        .animation(.easeInOut(duration: 0.8), value: song?.id)
    }
}

/// Taches de couleur qui dérivent et respirent avec les basses.
struct AuroraView: View {
    @EnvironmentObject var player: AudioEngine
    let colors: [Color]
    let animated: Bool

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30, paused: !animated)) { context in
            let time = context.date.timeIntervalSinceReferenceDate
            let pulse = CGFloat(animated ? player.bass : 0)
            Canvas { canvas, size in
                let base = max(size.width, size.height)
                for (offset, color) in colors.prefix(4).enumerated() {
                    let phase = Double(offset) * 1.7
                    let speed = 0.09 + Double(offset) * 0.025
                    let x = size.width * (0.5 + 0.38 * CGFloat(sin(time * speed + phase)))
                    let y = size.height * (0.45 + 0.35 * CGFloat(cos(time * speed * 1.3 + phase * 0.7)))
                    let radius = base * (0.42 + 0.06 * CGFloat(sin(time * 0.3 + phase))) * (1 + pulse * 0.35)
                    let rect = CGRect(x: x - radius, y: y - radius, width: radius * 2, height: radius * 2)
                    canvas.fill(Path(ellipseIn: rect),
                                with: .radialGradient(Gradient(colors: [color.opacity(0.95), color.opacity(0)]),
                                                      center: CGPoint(x: x, y: y), startRadius: 0, endRadius: radius))
                }
            }
            .blur(radius: 30)
        }
    }
}

/// Pochette agrandie, floutée, qui tourne lentement.
struct ArtworkBackdrop: View {
    let url: URL?
    let colors: [Color]
    let animated: Bool

    var body: some View {
        GeometryReader { geometry in
            let side = max(geometry.size.width, geometry.size.height) * 1.6
            TimelineView(.animation(minimumInterval: 1.0 / 20, paused: !animated)) { context in
                let angle = animated ? context.date.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 360) * 4 : 0
                ZStack {
                    LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing)
                    if let url = url {
                        LocalImage(url: url)
                    }
                }
                .frame(width: side, height: side)
                .rotationEffect(.degrees(angle))
                .blur(radius: 60)
                .position(x: geometry.size.width / 2, y: geometry.size.height / 2)
            }
        }
    }
}

/// Votre photo, avec un lent zoom (effet Ken Burns).
struct PhotoBackdrop: View {
    let image: UIImage?
    let colors: [Color]
    let animated: Bool

    var body: some View {
        GeometryReader { geometry in
            if let image = image {
                TimelineView(.animation(minimumInterval: 1.0 / 30, paused: !animated)) { context in
                    let time = context.date.timeIntervalSinceReferenceDate
                    let scale = animated ? 1.12 + 0.08 * sin(time / 9) : 1.05
                    let dx = animated ? 14 * cos(time / 11) : 0
                    let dy = animated ? 10 * sin(time / 13) : 0
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFill()
                        .frame(width: geometry.size.width, height: geometry.size.height)
                        .scaleEffect(scale)
                        .offset(x: dx, y: dy)
                        .clipped()
                }
            } else {
                AuroraView(colors: colors, animated: animated)
            }
        }
    }
}

/// Dégradé qui tourne avec les couleurs de la pochette.
struct RainbowBackdrop: View {
    let colors: [Color]
    let animated: Bool

    var body: some View {
        GeometryReader { geometry in
            let side = max(geometry.size.width, geometry.size.height) * 1.5
            TimelineView(.animation(minimumInterval: 1.0 / 30, paused: !animated)) { context in
                let angle = animated ? context.date.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 360) * 12 : 0
                AngularGradient(colors: colors + [colors.first ?? .pink], center: .center)
                    .frame(width: side, height: side)
                    .rotationEffect(.degrees(angle))
                    .blur(radius: 50)
                    .position(x: geometry.size.width / 2, y: geometry.size.height / 2)
            }
        }
    }
}

// MARK: - Pochette du lecteur

struct PlayerCover: View {
    @EnvironmentObject var player: AudioEngine
    @ObservedObject private var meter = AudioEngine.shared.meter
    @ObservedObject private var appearance = Appearance.shared
    @ObservedObject private var library = LibraryStore.shared
    let song: Song
    let size: CGFloat
    let namespace: Namespace.ID
    @State private var tilt: CGSize = .zero

    var body: some View {
        ZStack {
            if appearance.visualizer == .ring && appearance.coverStyle != .card {
                RingVisualizer(radius: size / 2 + 8, color: appearance.accent)
                    .frame(width: size + 90, height: size + 90)
            }
            switch appearance.coverStyle {
            case .square:
                SongArtwork(song: song, size: size, radius: 18)
                    .matchedGeometryEffect(id: "artwork", in: namespace)
                    .shadow(color: .black.opacity(0.45), radius: 26, y: 14)
                    .scaleEffect(player.isPlaying ? 1 + CGFloat(appearance.animations ? meter.bass : 0) * 0.04 : 0.84)
                    .animation(.spring(response: 0.5, dampingFraction: 0.68), value: player.isPlaying)
            case .vinyl:
                VinylView(song: song, size: size)
                    .matchedGeometryEffect(id: "artwork", in: namespace)
                    .scaleEffect(player.isPlaying ? 1 : 0.9)
                    .animation(.spring(response: 0.5, dampingFraction: 0.7), value: player.isPlaying)
            case .card:
                TimelineView(.animation(minimumInterval: 1.0 / 30, paused: !appearance.animations)) { context in
                    let time = context.date.timeIntervalSinceReferenceDate
                    let swayX = appearance.animations ? sin(time * 0.8) * 6 : 0
                    let swayY = appearance.animations ? cos(time * 0.6) * 6 : 0
                    SongArtwork(song: song, size: size, radius: 22)
                        .matchedGeometryEffect(id: "artwork", in: namespace)
                        .overlay(
                            LinearGradient(colors: [.white.opacity(0.35), .clear, .clear],
                                           startPoint: .topLeading, endPoint: .bottomTrailing)
                                .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                        )
                        .shadow(color: .black.opacity(0.5), radius: 30, x: -tilt.width / 6, y: 18)
                        .rotation3DEffect(.degrees(Double(-tilt.height / 8) + swayY), axis: (x: 1, y: 0, z: 0))
                        .rotation3DEffect(.degrees(Double(tilt.width / 8) + swayX), axis: (x: 0, y: 1, z: 0))
                        .scaleEffect(player.isPlaying ? 1 : 0.88)
                }
                .gesture(
                    DragGesture()
                        .onChanged { value in tilt = value.translation }
                        .onEnded { _ in
                            withAnimation(.spring(response: 0.5, dampingFraction: 0.5)) { tilt = .zero }
                        }
                )
                .animation(.spring(response: 0.5, dampingFraction: 0.7), value: player.isPlaying)
            }
        }
        .frame(width: size, height: size)
    }
}

/// Disque vinyle qui tourne au rythme de la lecture, la pochette au centre.
struct VinylView: View {
    @EnvironmentObject var player: AudioEngine
    @ObservedObject private var library = LibraryStore.shared
    let song: Song
    let size: CGFloat

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 60, paused: !player.isPlaying)) { context in
            let angle = liveTime(player, at: context.date) * 40
            ZStack {
                Circle().fill(
                    RadialGradient(colors: [Color(white: 0.16), Color(white: 0.04)], center: .center,
                                   startRadius: 0, endRadius: size / 2)
                )
                ForEach(0..<14, id: \.self) { ring in
                    Circle()
                        .stroke(Color.white.opacity(ring % 3 == 0 ? 0.08 : 0.04), lineWidth: 1)
                        .frame(width: size * (0.58 + CGFloat(ring) * 0.029), height: size * (0.58 + CGFloat(ring) * 0.029))
                }
                Artwork(url: library.artworkURL(song), seed: song.id, size: size * 0.5, radius: size * 0.25)
                Circle().fill(Color.black).frame(width: size * 0.05, height: size * 0.05)
                // Reflet de lumière fixe.
                AngularGradient(colors: [.clear, .white.opacity(0.12), .clear, .white.opacity(0.08), .clear],
                                center: .center)
                    .clipShape(Circle())
                    .rotationEffect(.degrees(-angle))
            }
            .frame(width: size, height: size)
            .rotationEffect(.degrees(angle))
            .shadow(color: .black.opacity(0.5), radius: 24, y: 12)
        }
    }
}

// MARK: - Visualiseurs

/// Barres qui dansent avec la musique.
struct BarsVisualizer: View {
    @EnvironmentObject var player: AudioEngine
    @ObservedObject private var meter = AudioEngine.shared.meter
    let color: Color

    var body: some View {
        GeometryReader { geometry in
            let count = meter.spectrum.count
            let spacing: CGFloat = 3
            let width = max(1, (geometry.size.width - spacing * CGFloat(count - 1)) / CGFloat(max(1, count)))
            HStack(alignment: .center, spacing: spacing) {
                ForEach(0..<count, id: \.self) { band in
                    let level = CGFloat(meter.spectrum[band])
                    Capsule()
                        .fill(LinearGradient(colors: [color, color.opacity(0.55), .white.opacity(0.8)],
                                             startPoint: .bottom, endPoint: .top))
                        .frame(width: width, height: max(3, geometry.size.height * level))
                }
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
            .animation(.linear(duration: 0.06), value: meter.spectrum)
        }
    }
}

/// Onde lisse (miroir) qui suit le spectre.
struct WaveVisualizer: View {
    @EnvironmentObject var player: AudioEngine
    @ObservedObject private var meter = AudioEngine.shared.meter
    let color: Color

    var body: some View {
        Canvas { canvas, size in
            let values = meter.spectrum
            guard values.count > 1 else { return }
            let middle = size.height / 2
            let step = size.width / CGFloat(values.count - 1)
            var top = Path()
            var bottom = Path()
            top.move(to: CGPoint(x: 0, y: middle))
            bottom.move(to: CGPoint(x: 0, y: middle))
            for (offset, value) in values.enumerated() {
                let x = CGFloat(offset) * step
                let height = CGFloat(value) * middle * 0.95
                let previousX = CGFloat(max(0, offset - 1)) * step
                let control = (previousX + x) / 2
                top.addQuadCurve(to: CGPoint(x: x, y: middle - height), control: CGPoint(x: control, y: middle - height))
                bottom.addQuadCurve(to: CGPoint(x: x, y: middle + height), control: CGPoint(x: control, y: middle + height))
            }
            top.addLine(to: CGPoint(x: size.width, y: middle))
            bottom.addLine(to: CGPoint(x: size.width, y: middle))
            var shape = top
            shape.addPath(bottom)
            canvas.fill(shape, with: .linearGradient(Gradient(colors: [color.opacity(0.9), .white.opacity(0.6), color.opacity(0.9)]),
                                                     startPoint: .zero, endPoint: CGPoint(x: size.width, y: 0)))
        }
    }
}

/// Anneau de rayons autour de la pochette.
struct RingVisualizer: View {
    @EnvironmentObject var player: AudioEngine
    @ObservedObject private var meter = AudioEngine.shared.meter
    let radius: CGFloat
    let color: Color

    var body: some View {
        Canvas { canvas, size in
            let values = meter.spectrum
            guard !values.isEmpty else { return }
            let center = CGPoint(x: size.width / 2, y: size.height / 2)
            let rays = values.count * 2
            for ray in 0..<rays {
                let band = ray < values.count ? ray : rays - 1 - ray
                let level = CGFloat(values[band])
                let angle = Double(ray) / Double(rays) * 2 * .pi - .pi / 2
                let length = 6 + level * 38
                let start = CGPoint(x: center.x + CGFloat(cos(angle)) * radius, y: center.y + CGFloat(sin(angle)) * radius)
                let end = CGPoint(x: center.x + CGFloat(cos(angle)) * (radius + length),
                                  y: center.y + CGFloat(sin(angle)) * (radius + length))
                var path = Path()
                path.move(to: start)
                path.addLine(to: end)
                canvas.stroke(path, with: .color(color.opacity(0.55 + Double(level) * 0.45)),
                              style: StrokeStyle(lineWidth: 3, lineCap: .round))
            }
        }
    }
}
