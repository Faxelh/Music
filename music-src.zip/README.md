# Music

Lecteur de musique pour iPhone (SwiftUI), puissant, animé et personnalisable.

- Bibliothèque : morceaux, artistes, albums, playlists (avec photo de couverture), favoris, les plus écoutés, dossiers.
- Sons ajoutés avec 3uTools / iTunes (Apps › Music › Documents), l'app Fichiers ou « Ouvrir avec » : affichés automatiquement.
- Lecteur animé : fonds (aurore qui respire avec les basses, pochette floue, votre photo, dégradé), pochette carrée / vinyle qui tourne / carte 3D, visualiseur (barres, anneau, onde).
- Paroles synchronisées : fichier, .lrc, recherche en ligne (LRCLIB), génération par reconnaissance vocale, écriture et synchronisation à la main.
- Égaliseur 10 bandes avec préréglages, vitesse sans changer la voix, minuteur, file d'attente, AirPlay, écran verrouillé.
- Personnalisation : prénom et photo de profil, couleur, fond du lecteur, styles.

Construction : GitHub Actions (`.github/workflows/music.yml`) → artefact **Music-iPhone** → `Music.ipa` (Sideloadly).
